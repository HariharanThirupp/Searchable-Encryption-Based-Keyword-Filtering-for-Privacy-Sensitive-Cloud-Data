/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package ascon;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.security.*;
import java.util.ArrayList;
import java.security.spec.*;
import java.util.Base64;
import javax.servlet.http.HttpSession;

/**
 *
 * @author manimaran
 */
@WebServlet(name = "DecryptAndVerify", urlPatterns = {"/DecryptAndVerify"})
public class DecryptAndVerify extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    DBConnection dbn=new DBConnection();
    Statement st=dbn.stt;
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        ArrayList DeviceIds=new ArrayList();
        ArrayList PubKeys=new ArrayList();
        ArrayList MastKeys=new ArrayList();
        try 
        {
            ResultSet rs = st.executeQuery("select * from usersignup");
            while (rs.next()) 
            {
                String DeviceId = rs.getString(1);
                String PublicKey = rs.getString(5);
                String masterkey = rs.getString(6);
                DeviceIds.add(DeviceId.trim());
                PubKeys.add(PublicKey.trim());
                MastKeys.add(masterkey.trim());
            }
        }
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        
        try 
        {
            String res="";
            ResultSet rs = st.executeQuery("select * from message");
            while (rs.next()) 
            {
                String SNo = rs.getString(1);
                String DevId = rs.getString(2);
                String cipherString = rs.getString(3);
                String signatureString = rs.getString(4);
                
                // Convert String back to byte[]
                byte[] cipher = Base64.getDecoder().decode(cipherString);
                byte[] signature = Base64.getDecoder().decode(signatureString);
                
                int devind=DeviceIds.indexOf(DevId.trim());
                String masterKeyStr = MastKeys.get(devind).toString().trim();
                String publicKeyStr = PubKeys.get(devind).toString().trim();
                
                byte[] masterKey = Base64.getDecoder().decode(masterKeyStr);                
                
                // Algo 6 – XOF128
                byte[] sessionKey = CryptoPrimitives.XOF128(masterKey, 32);

                // Algo 7 – CXOF128
                byte[] finalKey = CryptoPrimitives.CXOF128(sessionKey, "AEAD-CONTEXT", 32);

                // Algo 4 – AEAD.dec
                byte[] plain = CryptoPrimitives.AEAD_dec(cipher, finalKey);

                KeyFactory keyFactory = KeyFactory.getInstance("DSA");
                
                // Restore Public Key
                byte[] publicKeyBytes = Base64.getDecoder().decode(publicKeyStr);
                X509EncodedKeySpec publicKeySpec = new X509EncodedKeySpec(publicKeyBytes);
                PublicKey publicKey = keyFactory.generatePublic(publicKeySpec);
                
                Signature sig = Signature.getInstance("SHA256withDSA");
                sig.initVerify(publicKey);
                sig.update(cipher);
                boolean valid = sig.verify(signature);

                String message=new String(plain).trim();
                
                System.out.println("Decrypted Message: " + message.trim());
                System.out.println("Signature Valid: " + valid);
                System.out.println();
                
                res=res+SNo+"##"+DevId+"##"+message+"##"+valid+"@@";
            }
            HttpSession hs=request.getSession(true);
            String resul=res.substring(0,res.lastIndexOf('@'));
            String result=resul.substring(0,resul.lastIndexOf('@'));
            hs.setAttribute("result", result.trim());
            
            out.println("<script type=\"text/javascript\">");
            out.println("alert('Decrypt Successfully!');");
            out.println("location='ServerHome1.jsp';");
            out.println("</script>");
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
        }
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
