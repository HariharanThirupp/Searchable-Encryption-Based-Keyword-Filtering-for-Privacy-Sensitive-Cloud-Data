/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package ascon;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Base64;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.http.HttpSession;

/**
 *
 * @author manimaran
 */
@WebServlet(name = "EncryptAndSend", urlPatterns = {"/EncryptAndSend"})
@MultipartConfig(
    location = "C:/ASCONUploads",
    fileSizeThreshold = 1024 * 1024,
    maxFileSize = 1024 * 1024 * 5,
    maxRequestSize = 1024 * 1024 * 10
)
public class EncryptAndSend extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    DBConnection dbn=new DBConnection();
    Statement st=dbn.stt;
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String message = request.getParameter("message");
        
        HttpSession sn=request.getSession(true);
        String DevId=sn.getAttribute("DevId").toString();
        String mastkey=sn.getAttribute("mastkey").toString();
        String privkey=sn.getAttribute("privkey").toString();
        
        try
        {
            // Restore Master Key
            byte[] masterKey = Base64.getDecoder().decode(mastkey);
            
            byte[] msgBytes = message.getBytes();

            // Algo 6 – XOF128
            byte[] sessionKey = CryptoPrimitives.XOF128(masterKey, 32);

            // Algo 7 – CXOF128
            byte[] finalKey = CryptoPrimitives.CXOF128(sessionKey, "AEAD-CONTEXT", 32);

            // Algo 5 – Hash256
            byte[] fingerprint = CryptoPrimitives.Hash256(msgBytes);

            // Algo 3 – AEAD.enc
            byte[] cipher = CryptoPrimitives.AEAD_enc(msgBytes, finalKey);

            // Digital Signature
            KeyFactory keyFactory = KeyFactory.getInstance("DSA");
            byte[] privKeyBytes = Base64.getDecoder().decode(privkey);
            PKCS8EncodedKeySpec privSpec = new PKCS8EncodedKeySpec(privKeyBytes);
            PrivateKey priv = keyFactory.generatePrivate(privSpec);

            Signature sig = Signature.getInstance("SHA256withDSA");
            sig.initSign(priv);
            sig.update(cipher);
            byte[] signature = sig.sign();
            
            // Convert byte[] to String
            String cipherString = Base64.getEncoder().encodeToString(cipher);
            String signatureString = Base64.getEncoder().encodeToString(signature);
            
            int sno=0;
            try 
            {
                ResultSet rs = st.executeQuery("select * from message");
                while (rs.next()) 
                {
                    sno++;
                }
                sno++;        
            }
            catch(Exception e1)
            {
               e1.printStackTrace();
            }
            
            st.executeUpdate("insert into Message values('"+sno+"','"+DevId.trim()+"','"+cipherString.trim()+"','"+signatureString.trim()+"')");                

            out.println("<script type=\"text/javascript\">");
            out.println("alert('Encrypted and Ciphertext sent to server successfully!');");
            out.println("location='DeviceHome.jsp';");
            out.println("</script>");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
