/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package ascon;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Statement;
import javax.servlet.http.HttpSession;
import java.security.*;
import java.util.Base64;

/**
 *
 * @author manimaran
 */
@WebServlet(name = "UserSignUp", urlPatterns = {"/UserSignUp"})
public class UserSignUp extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    DBConnection dbn=new DBConnection();
    Statement st=dbn.stt;
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        HttpSession hs=request.getSession(true);
        
        String deviceId=request.getParameter("deviceId");
        String secretKey=request.getParameter("secretKey"); 
        String deviceType=request.getParameter("deviceType");
        
        try
        {
            // ===============================
            // 1. Generate DSA Key Pair
            // ===============================
            KeyPairGenerator kpg = KeyPairGenerator.getInstance("DSA");
            kpg.initialize(2048);
            KeyPair signKeyPair = kpg.generateKeyPair();

            PrivateKey privateKey = signKeyPair.getPrivate();
            PublicKey publicKey = signKeyPair.getPublic();

            // ===============================
            // 2. Convert Keys to String
            // ===============================
            String privateKeyStr = Base64.getEncoder()
                    .encodeToString(privateKey.getEncoded());

            String publicKeyStr = Base64.getEncoder()
                    .encodeToString(publicKey.getEncoded());

            // Master symmetric key
            byte[] masterKey = "ReceiverMasterKey".getBytes();
            String masterKeyStr = Base64.getEncoder()
                    .encodeToString(masterKey);

            System.out.println("Private Key String:\n" + privateKeyStr);
            System.out.println("Public Key String:\n" + publicKeyStr);
            System.out.println("Master Key String:\n" + masterKeyStr);
            
            ResultSet rs=st.executeQuery("select * from UserSignUp where DeviceId='"+deviceId.trim()+"' and SecretKey='"+secretKey.trim()+"'");
            if(rs.next())
            {                
                out.println("<script type=\"text/javascript\">");
                out.println("alert('These Values are already exists!');");
                out.println("location='UserSignUp.jsp';");
                out.println("</script>");
            }
            else
            {
                st.executeUpdate("insert into UserSignUp values('"+deviceId.trim()+"','"+secretKey.trim()+"','"+deviceType.trim()+"','"+privateKeyStr.trim()+"','"+publicKeyStr.trim()+"','"+masterKeyStr.trim()+"')");                

                out.println("<script type=\"text/javascript\">");
                out.println("alert('Registered Successfully! Server generated Keys for this device');");
                out.println("location='UserSignUp.jsp';");
                out.println("</script>");                               
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
