/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ascon;

import java.security.MessageDigest;
import java.util.Arrays;

public class CryptoPrimitives {

    // Algo 1 – parse
    public static byte[][] parse(byte[] input, int blockSize) {
        int blocks = (int) Math.ceil((double) input.length / blockSize);
        byte[][] out = new byte[blocks][blockSize];
        for (int i = 0; i < blocks; i++) {
            System.arraycopy(input, i * blockSize, out[i], 0,
                    Math.min(blockSize, input.length - i * blockSize));
        }
        return out;
    }

    // Algo 2 – pad
    public static byte[] pad(byte[] data, int blockSize, byte domain) {
        int padLen = blockSize - (data.length % blockSize);
        byte[] out = Arrays.copyOf(data, data.length + padLen);
        out[data.length] = domain;
        return out;
    }
    
    // Algo 3 – AEAD.enc
    public static byte[] AEAD_enc(byte[] msg, byte[] key) throws Exception {
        byte[] padded = pad(msg, 16, (byte) 0x01);
        byte[] ks = XOF128(key, padded.length);
        byte[] cipher = new byte[padded.length];
        for (int i = 0; i < padded.length; i++) {
            cipher[i] = (byte) (padded[i] ^ ks[i]);
        }
        return cipher;
    }

    // Algo 4 – AEAD.dec
    public static byte[] AEAD_dec(byte[] cipher, byte[] key) throws Exception {
        byte[] ks = XOF128(key, cipher.length);
        byte[] plain = new byte[cipher.length];
        for (int i = 0; i < cipher.length; i++) {
            plain[i] = (byte) (cipher[i] ^ ks[i]);
        }
        return plain;
    }

    // Algo 5 – Hash256
    public static byte[] Hash256(byte[] data) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        return md.digest(data);
    }

    // Algo 6 – XOF128 (simple expansion)
    public static byte[] XOF128(byte[] seed, int outLen) throws Exception {
        byte[] out = new byte[outLen];
        byte[] state = seed;
        int pos = 0;
        while (pos < outLen) {
            state = Hash256(state);
            int copy = Math.min(state.length, outLen - pos);
            System.arraycopy(state, 0, out, pos, copy);
            pos += copy;
        }
        return out;
    }

    // Algo 7 – CXOF128
    public static byte[] CXOF128(byte[] key, String context, int outLen) throws Exception {
        byte[] ctx = context.getBytes();
        byte[] combined = new byte[key.length + ctx.length];
        System.arraycopy(key, 0, combined, 0, key.length);
        System.arraycopy(ctx, 0, combined, key.length, ctx.length);
        return XOF128(combined, outLen);
    }

    
}
